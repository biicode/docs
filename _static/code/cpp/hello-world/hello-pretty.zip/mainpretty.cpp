#include "hellopretty.h"

int main(){
    hellopretty();
    return 1;
}