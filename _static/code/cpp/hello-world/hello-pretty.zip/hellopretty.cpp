#include "your_user_name/my_block/hello.h" //reusing hello.h header
#include "hellopretty.h"
#include <iostream>

using namespace std;

void hellopretty (){
   cout<<"**********************************"<<endl;
   hello();
   cout<<"**********************************"<<endl;
}