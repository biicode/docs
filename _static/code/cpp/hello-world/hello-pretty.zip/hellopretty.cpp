#include "your_user_name/cpp_hello/hello.h" //reusing hello.h header
#include "hellopretty.h"
#include <iostream>

using namespace std;

void hellopretty (){
   cout<<"**********************************"<<endl;
   hello();
   cout<<"**********************************"<<endl;
}