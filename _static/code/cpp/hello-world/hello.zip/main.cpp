#include "hello.h"

int main() {
  hello();
  return 1;
}