#pragma once

//Method to print "Hello World!"
void hello();