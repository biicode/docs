#include "hello.h"
#include  <iostream>
using namespace std;

void hello(){
 cout<<"Hello world!"<<endl;
}